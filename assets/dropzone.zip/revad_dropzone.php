<!DOCTYPE html>

<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>

<link rel="stylesheet" type="text/css" href="assets/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="assets/dropzone.css"/>
<link rel="stylesheet" type="text/css" href="assets/custom.css"/>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="assets/dropzone.min.js"></script>
<!----- UI TREE ----->
<link rel="stylesheet" type="text/css" href="assets/ui_tree/font-awesome/css/font-awesome.min.css"/>
<link rel="stylesheet" type="text/css" href="assets/ui_tree/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="assets/ui_tree/jstree/themes/style.min.css"/>

</head>

<body>
<?php
$order_id = $_GET['order_id'];
$slug = $_GET['slug'];
$order_type = $_GET['order_type'];
$new_slug = $_GET['new_slug_name'];
?>
<div class="container">
	<div class="row">									
		<div class="col-md-6 col-sm-6 col-xs-6 margin-bottom-15">	
		  <div class="row no-space border-dashed">
				<div class="col-md-4 col-sm-3 col-xs-4 no-space">	
					<img class="padding-6" src="assets/img/indd.jpg" alt="indd" width="100%">
				</div>	
				
				<?php if($order_type == '1') { ?>
							<div class="col-md-8 col-sm-9 col-xs-8">	
								<form action="revad_upload.php"  id="dropzonepsd" class="dropzone" method="post">
									<input type="hidden" name="slug_name" id="slug_name" class="form-control margin-bottom-15" title="" value="<?php echo $new_slug;  ?>">
									<input type="hidden" name="file_type" id="file_type" class="form-control margin-bottom-15" title="" value="psd">
									<input type="hidden" name="order_id" value="<?php echo $order_id;  ?>">
									<input type="hidden" name="cat_slug" value="<?php echo $slug; ?>">
									<div class="dz-default dz-message margin-top-20">
										<span>PSD File</span>
									</div>
								</form>
							</div>
							<?php } else { ?>
							<div class="col-md-8 col-sm-9 col-xs-8">	
								<form action="revad_upload.php"  id="dropzoneindd" class="dropzone" method="post">
									<input type="hidden" name="slug_name" id="slug_name" class="form-control margin-bottom-15" title="" value="<?php echo $new_slug;  ?>">
									<input type="hidden" name="file_type" id="file_type" class="form-control margin-bottom-15" title="" value="indd">
									<input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
									<input type="hidden" name="cat_slug" value="<?php echo $slug; ?>">
									<div class="dz-default dz-message margin-top-20">
										<span>Indesign File</span>
									</div>
								</form>
							</div>
							<?php } ?>
							
			</div>
		</div>
		<div class="col-md-6 col-sm-6 col-xs-6 margin-bottom-15">	
		  <div class="row no-space border-dashed">
				<div class="col-md-4 col-sm-3 col-xs-4 no-space">	
					<img class="padding-6" src="assets/img/pdf.jpg" alt="indd" width="100%">
				</div>	
				
			<?php if($order_type == '1') { ?>
							<div class="col-md-8 col-sm-9 col-xs-8">	
								<form action="revad_upload.php"   id="dropzoneimages" class="dropzone" method="post">
									<input type="hidden" name="slug_name" id="slug_name" class="form-control margin-bottom-15" title="" value="<?php echo $new_slug;  ?>">
									<input type="hidden" name="file_type" id="file_type" class="form-control margin-bottom-15" title="" value="images">
									<input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
									<input type="hidden" name="cat_slug" value="<?php echo $slug; ?>">
									<div class="dz-default dz-message margin-top-20">
										<span>Image File</span>
									</div>
								</form>
							</div>	
							<?php } else { ?>
							<div class="col-md-8 col-sm-9 col-xs-8">	
								<form action="revad_upload.php"   id="dropzonepdf" class="dropzone" method="post">
									<input type="hidden" name="slug_name" id="slug_name" class="form-control margin-bottom-15" title="" value="<?php echo $new_slug;  ?>">
									<input type="hidden" name="file_type" id="file_type" class="form-control margin-bottom-15" title="" value="pdf">
									<input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
									<input type="hidden" name="cat_slug" value="<?php echo $slug; ?>">
									<div class="dz-default dz-message margin-top-20">
										<span>PDF File</span>
									</div>
								</form>
							</div>
			<?php } ?>
			</div>
		</div>
	</div>
			
	<div class="row">
		<div class="col-xs-6 margin-bottom-15">	
		  <div class="row no-space border-dashed" id="links">
				<div class="col-md-4 col-sm-3 col-xs-4 no-space">	
					<img class="padding-6" src="assets/img/links.jpg" alt="indd" width="100%">
				</div>	
				<div class="col-md-12 col-sm-12 col-xs12 no-space">	
					<form action="revad_upload.php"   id="dropzone" class="dropzone" method="post">
						<input type="hidden" name="slug_name" id="slug_name" class="form-control margin-bottom-15" title="" value="<?php echo $new_slug;  ?>">
						<input type="hidden" name="file_type" id="file_type" class="form-control margin-bottom-15" title="" value="links">
						<input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
						<input type="hidden" name="cat_slug" value="<?php echo $slug; ?>">
						<div class="dz-default dz-message margin-top-20 margin-bottom-20">
							<span>Links File</span>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-xs-6 margin-bottom-15">	
		  <div class="row no-space border-dashed" id="links">
				<div class="col-md-4 col-sm-3 col-xs-4 no-space">	
					<img class="padding-6" src="assets/img/fonts.jpg" alt="indd" width="100%">
				</div>	
				<div class="col-md-12 col-sm-12 col-xs12 no-space">	
								<form action="revad_upload.php"   id="dropzone" class="dropzone" method="post">
									<input type="hidden" name="slug_name" id="slug_name" class="form-control margin-bottom-15" title="" value="<?php echo $new_slug;  ?>">
									<input type="hidden" name="file_type" id="file_type" class="form-control margin-bottom-15" title="" value="fonts">
									<input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
									<input type="hidden" name="cat_slug" value="<?php echo $slug; ?>">
									<div class="dz-default dz-message margin-top-20 margin-bottom-20">
										<span>Fonts File</span>
									</div>
								</form>
				</div>
			</div>
		</div>
	</div>
</div>

<?php 
	$source = 'sourcefile/'.$order_id.'/'.$slug;
	$links = 'sourcefile/'.$order_id.'/'.$slug.'/Links';
	$fonts = 'sourcefile/'.$order_id.'/'.$slug.'/Document fonts';
	if(is_dir($source)){
?>
<div class="container">			
	<div id="tree_1" class="tree-demo">
		<ul>
			<li> <?php echo $order_id; ?>
				<ul>
				<?php
					if ($handle = opendir($source)) {
						while (false !== ($entry = readdir($handle))) { 
							if ($entry != "." && $entry != "..") {
								if($entry == 'Links' || $entry == 'Document fonts'){ 
									continue;
								}else{ ?>
									<li data-jstree='{ "type" : "file" }'>
										<a href="javascript:;">
										<?php echo "$entry"; ?> </a>
									</li>
				<?php } } } } ?>
				<!-- fonts -->
				<li data-jstree='{ "opened" : true }'>
					Document fonts
				<?php
					if ($handle = opendir($fonts)) {
						while (false !== ($entry = readdir($handle))) { 
							if ($entry != "." && $entry != "..") {
				?>
						<ul>
							<li data-jstree='{ "type" : "file" }'>
								 <?php echo "$entry"; ?>
							</li>
						</ul>
					<?php } } } ?>	
				</li>
				<!-- links -->
				<li data-jstree='{ "opened" : true }'>
					Links
				<?php
					if ($handle = opendir($links)) {
						while (false !== ($entry = readdir($handle))) { 
							if ($entry != "." && $entry != "..") {
				?>
						<ul>
							<li data-jstree='{ "type" : "file" }'>
								 <?php echo "$entry"; ?>
							</li>
						</ul>
					<?php } } } ?>	
				</li>	
				</ul>
			</li>
		</ul>
	</div>
</div>
<?php } ?>
		
</body>
<!-- END BODY -->
<script src="assets/ui_tree/jquery.min.js" type="text/javascript"></script>
<script src="assets/ui_tree/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/ui_tree/jstree/jstree.min.js"></script>
<script src="assets/ui_tree/ui-tree.js"></script>
<script>
        jQuery(document).ready(function() {   
            UITree.init();
        });
</script>		
</body>
<!-- END BODY -->
<script>
Dropzone.options.dropzonepsd = {
	init: function() {
		this.on("sending", function(file)
		{ 
			var string1_value = $(slug_name).val() + ".psd";
			var string2_value = file.name;
			if(string1_value != string2_value)
			{
				alert("Wrong file. File will be removed");
				this.removeFile(file);
			}		
		 });
	}
};

Dropzone.options.dropzoneindd = {
	init: function() {
		this.on("sending", function(file) 
		{ 
			var string1_value = $(slug_name).val() + ".indd";
			var string2_value = file.name;
			if(string1_value != string2_value)
			{
				alert("Wrong file. File will be removed");
				this.removeFile(file);
			}
		 });
	}
};

Dropzone.options.dropzoneimages = {
	init: function() {
		this.on("sending", function(file)
		{ 
			 var string1_value = $(slug_name).val();
			 var input_file_value = file.name;
			 var string2_value = input_file_value.substr(0, input_file_value.lastIndexOf('.'));
			if(string1_value != string2_value )
			{
				alert("Wrong file. File will be removed");
				this.removeFile(file);
			}
		 });
	}
};

Dropzone.options.dropzonepdf = {
	init: function() {
		this.on("sending", function(file)
		{ 
			var string1_value = $(slug_name).val() + ".pdf";
			var string2_value = file.name;
			if(string1_value != string2_value)
			{
				alert("Wrong file. File will be removed");
				this.removeFile(file);
			}
		 });
	}
};
</script>


