<?php
$order_id = $_POST['order_id'];
$slug = $_POST['slug_name'];
$filetype = $_POST['file_type'];
$cat_slug = $_POST['cat_slug'];

$source_path = 'sourcefile'.'/'.$order_id.'/'.$cat_slug ;
if(!is_dir($source_path)){
	$dir4= "sourcefile/".$order_id;
	$dir5= $dir4.'/'.$cat_slug;
	if (@mkdir($dir4,0777)){	}
	if (@mkdir($dir5,0777)){	}
}
		//Links folder
		$link_path = $source_path.'/Links';
		if (@mkdir($link_path,0777)){}
		
		//Document fonts folder
		$font_path = $source_path.'/Document fonts';
		if (@mkdir($font_path,0777)){}	
			
		
		if($filetype == 'indd' || $filetype == 'psd' || $filetype == 'pdf' || $filetype == 'images'){
			if(!empty($_FILES))
			{
				$path = $source_path;
				if (@mkdir($path,0777)){}
				$tempFile = $_FILES['file']['tmp_name'];
				$fileName = $_FILES['file']['name'];
				if(!move_uploaded_file($tempFile, $path.'/'.$fileName)){
					echo "<script>alert('Error Uploading File.. Try Again..!!')</script>";
				}
			}
		}elseif($filetype == 'fonts'){
			if(!empty($_FILES))
			{
				$path = $source_path.'/Document fonts';
				if (@mkdir($path,0777)){}
				$tempFile = $_FILES['file']['tmp_name'];
				$fileName = $_FILES['file']['name'];
				if(!move_uploaded_file($tempFile, $path.'/'.$fileName)){
					echo "<script>alert('Error Uploading File.. Try Again..!!')</script>";
				}
			}
		}elseif($filetype == 'links'){
			if(!empty($_FILES))
			{
				$path = $source_path.'/Links';
				if (@mkdir($path,0777)){}
				$tempFile = $_FILES['file']['tmp_name'];
				$fileName = $_FILES['file']['name'];
				if(!move_uploaded_file($tempFile, $path.'/'.$fileName)){
					echo "<script>alert('Error Uploading File.. Try Again..!!')</script>";
				}
			}
		}
?>