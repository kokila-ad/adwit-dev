<?php
$order_id = $_GET['order_id'];
$slug = $_GET['slug'];
if(isset($_GET['new_slug'])){ $new_slug = $_GET['new_slug']; }else{ $new_slug = $slug; }
// Get real path for our folder
$rootPath = "sourcefile/$order_id/$slug";

// Initialize archive object
$zip = new ZipArchive();
$zip->open("$rootPath/$new_slug.zip", ZipArchive::CREATE | ZipArchive::OVERWRITE);

// Create recursive directory iterator
/** @var SplFileInfo[] $files */
$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($rootPath),
    RecursiveIteratorIterator::LEAVES_ONLY
);

foreach ($files as $name => $file){
    // Skip directories (they would be added automatically)
    if (!$file->isDir()){
        // Get real and relative path for current file
        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($rootPath) + 1);
		
		$last_dir = basename(dirname($filePath));
		if($last_dir == 'Document fonts' || $last_dir == 'Links'){
				$fname = basename($relativePath);
				$relativePath = $last_dir.'/'.$fname;
				// Add current file to archive
				$zip->addFile($filePath, $relativePath);
				continue;
		}else{
			$last_file = basename($filePath);
			$relativePath = basename($relativePath);
			if($last_file == $new_slug.'.indd'){
				$zip->addFile($filePath, $relativePath);
				continue;
			}elseif($last_file == $new_slug.'.psd'){
				$zip->addFile($filePath, $relativePath);
				continue;
			}elseif($last_file == $new_slug.'.pdf'){
				$zip->addFile($filePath, $relativePath);
				continue;
			}elseif($last_file == $new_slug.'.jpg'){
				$zip->addFile($filePath, $relativePath);
				continue;
			}elseif($last_file == $new_slug.'.gif'){
				$zip->addFile($filePath, $relativePath);
				continue;
			}
		}
	}
}

// Zip archive will be created only after closing object
$zip->close();

?>