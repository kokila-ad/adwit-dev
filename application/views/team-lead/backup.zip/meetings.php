<?php
       $this->load->view("team-lead/head");
?>

<?php
       $this->load->view("team-lead/foot");
?>