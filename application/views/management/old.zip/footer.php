
<!-- Footer starts -->
  <div id="Footer">
  <div id="footer-copy">&copy; <a href="http://www.adwitglobal.com/" target="_blank">Adwit Global</a></div>
  <div id="footer-version">version 3.0</div>
  </div> 
  <!-- Footer Ends -->


</div>
</body>
</html>