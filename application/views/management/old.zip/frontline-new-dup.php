<?php
       $this->load->view("management/header");
?>
        <link href="theme001/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="theme001/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="theme001/assets/styles.css" rel="stylesheet" media="screen">
        <link href="theme001/assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <script src="theme001/vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>

<link rel="stylesheet" href="jq-ui/themes/base/jquery.ui.all.css" />
<script src="jq-ui/ui/jquery.ui.core.js"></script>
<script src="jq-ui/ui/jquery.ui.datepicker.js"></script>

<script type="text/javascript">
	
	$(document).ready(function($) {    

   		$( "#from_date" ).datepicker({ minDate: "-14M", maxDate: 0, dateFormat: 'yy-mm-dd' });
		
		$( "#to_date" ).datepicker({ minDate: "-14M", maxDate: 0, dateFormat: 'yy-mm-dd'});
		
		
		
	});
	
</script>
<script type="text/javascript">
	$(document).ready(function(e) {
        $('#category').change(function(e) {
            window.location = "<?php echo base_url().index_page().'management/home/frontline/';?>" + $('#category').val() ;
        });
    });
</script>		
		
  <div id="Middle-Div">
  <div style="width: 90%; margin:0 auto; height: 30px;">
  <div style="float: right; "> 
        	Select Type&nbsp;
        	<select id="category" name="category">
            <option value="">Select</option>
        	<?php
			$types = $this->db->get('frontline_timer')->result_array();
				foreach($types as $type)
				{
					echo '<option value="'.$type['cat_name'].'" '.($form==$type['cat_name'] ? 'selected="selected"' : '').'>'.$type['cat_name'].'</option>';	
				}
			?>
            </select>
   </div>
   <div  style="float: left; ">
							<form method="post">
							From <input type="text" name="from_date" id="from_date" placeholder="YY-MM-DD"/> To<input type="text" name="to_date" id="to_date" placeholder="YY-MM-DD"/>
							<input type="submit" value="Submit" />
							</form>
							</div>
                            </div>
		
   <div class="row-fluid" style="width:96%; margin: 0 auto;">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
							
                                <div class="muted pull-left">Frontline <?php echo ucfirst($form); ?> Report : <?php if(isset($from) && isset($to)){echo $from." to ".$to;}else{echo $today;} ?> 
								</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
	<!-- Design9 -->
<?php foreach($help_desk as $hd_row){ ?>	
  	<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" >
										<thead>
											<tr>
												<th><?php echo $hd_row['name']; ?></th>
												<th>Total</th>
												<th>0-60mins</th>
												<th>61-120mins</th>
												<th>121-180mins</th>
												<th>181-240mins</th>
												<th>above 240mins</th>
											</tr>
										</thead>
										<tbody>
										
<?php										
		$tot_r_design9 = 0;
		$Dr_row1 = 0; $Dr_row2 = 0 ; $Dr_row3 = 0 ; $Dr_row4 = 0 ; $Dr_row5 = 0 ; $Dr_row6 = 0 ; $Dr_rest = 0;
		
		$Dr_row1_percentage = 0; $Dr_row2_percentage = 0; $Dr_row3_percentage = 0; $Dr_row4_percentage = 0; $Dr_row5_percentage = 0; $Dr_row6_percentage = 0; $Dr_rest_percentage = 0;
		foreach($rev_sold as $row)
		{
			if($row['help_desk'] == $hd_row['id'])
			{
				$tot_r_design9++;
				if($row['time_taken']<='3600')
				{
					$Dr_row1++;
				}elseif($row['time_taken']>'3600' && $row['time_taken']<='7200')
				{
					$Dr_row2++;
				}elseif($row['time_taken']>'7200' && $row['time_taken']<='10800')
				{
					$Dr_row3++;
				}elseif($row['time_taken']>'10800' && $row['time_taken']<='14400')
				{
					$Dr_row4++;
				}else{
					$Dr_rest++;
				}
			}
		}
		
		if($tot_r_design9!='0')
		{
			$Dr_row1_percentage = ($Dr_row1 / $tot_r_design9)*100 ;
			$Dr_row2_percentage = ($Dr_row2 / $tot_r_design9)*100 ;
			$Dr_row3_percentage = ($Dr_row3 / $tot_r_design9)*100 ;
			$Dr_row4_percentage = ($Dr_row4 / $tot_r_design9)*100 ;
			
			$Dr_rest_percentage = ($Dr_rest / $tot_r_design9)*100 ;
		}
?>								
											<tr class="odd gradeX">
												<td><?php echo "No"; ?></td>
												<td><?php echo $tot_r_design9; ?></td>
												<td><?php echo $Dr_row1; ?></td>
												<td><?php echo $Dr_row2; ?></td>
												<td><?php echo $Dr_row3; ?></td>
												<td><?php echo $Dr_row4; ?></td>
												
												<td><?php echo $Dr_rest; ?></td>
												
											</tr>
											<tr class="odd gradeX">
												<td><?php echo "Percentage"; ?></td>
												<td><?php echo ''; ?></td>
												<td><?php echo round($Dr_row1_percentage,2).'%'; ?></td>
												<td><?php echo round($Dr_row2_percentage,2).'%'; ?></td>
												<td><?php echo round($Dr_row3_percentage,2).'%'; ?></td>
												<td><?php echo round($Dr_row4_percentage,2).'%'; ?></td>
												<td><?php echo round($Dr_rest_percentage,2).'%'; ?></td>
												
											</tr>
										</tbody>
									</table>
<?php } ?>	
                                </div>
                            </div>
                        </div>
                        </div>
  </div>
  
    <script src="theme001/vendors/jquery-1.9.1.js"></script>
        <script src="theme001/bootstrap/js/bootstrap.min.js"></script>
        <script src="theme001/vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="theme001/assets/scripts.js"></script>
        <script src="theme001/assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>

                       
<?php
       $this->load->view("management/footer");
?>