<?php
	$this->load->view("management/header");
?>
    
	
	<div id="Middle-Div">
    <div id="Middle-text">Welcome <?php echo $this->session->userdata('management');?></div>
  </div> 
			
<?php
	$this->load->view("management/footer");
?>