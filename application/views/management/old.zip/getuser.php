<?php
$emp=$_GET["q"];
$cat=$_GET["p"];
$id=$_GET["r"];

echo "submited";
?>