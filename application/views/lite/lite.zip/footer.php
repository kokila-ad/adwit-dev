 
 <footer class="footer">             
	<div class="footer-copyright">
		<div class="container">
			<div class="copyright">
				<p>Copyright &copy; 2016 Adwit Global - All Rights Reserved.</p>
			</div>

			<div class="footer-nav">
				<nav>
					<ul>
						<li><a href="http://www.adwitglobal.com/about/" target="_blank">About Us</a></li>
						<li><a href="http://www.adwitglobal.com/ad-production-services/" target="_blank">Contact Us</a></li>
						<li><a href="http://www.adwitglobal.com/terms-of-use/" target="_blank">Terms of Use</a></li>
						<li><a href="http://www.adwitglobal.com/privacy-policy/" target="_blank">Privacy Policy</a></li>
					</ul>
					<!--<ul>
						<li><a href="<?php echo base_url().index_page(); ?>lite/home/contact_us">Contact Us</a></li>
						<li><a href="<?php echo base_url().index_page(); ?>lite/home/terms">Term of Use</a></li>
						<li><a href="<?php echo base_url().index_page(); ?>lite/home/privacy_policy">Privacy Policy</a></li>
						<li><a href="<?php echo base_url().index_page(); ?>lite/home/about_us">About us</a></li>
						<li><a href="<?php echo base_url().index_page(); ?>lite/home/site_map">Site Map</a></li>
					</ul>-->
				</nav>
			</div>
		</div>
	</div><!-- /.footer-copyright -->
</footer><!-- /footer -->

</div><!-- /#wrapper -->





   