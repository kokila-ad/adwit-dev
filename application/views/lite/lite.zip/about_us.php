<?php $this->load->view("lite/head.php"); ?>
<?php $this->load->view("lite/header.php"); ?> 

<div class="container">
  <h2 class=""> About Us</h2>
</div>


<?php $this->load->view("lite/footer.php"); ?>
 <?php $this->load->view("lite/foot.php"); ?>

