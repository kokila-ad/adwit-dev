	<script src="<?php echo base_url(); ?>assets/new_client/js/dropzone.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/new_client/js/datatables.min.js"></script>	  
    <script src="<?php echo base_url(); ?>assets/new_client/js/awe-hosoren.js"></script>	
	<script src="<?php echo base_url(); ?>assets/lite/js/jquery-ui.min.js"></script>	
	<script src="<?php echo base_url(); ?>assets/lite/js/plugins/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lite/js/plugins/awemenu.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lite/js/plugins/headroom.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lite/js/plugins/jquery.parallax-1.1.3.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lite/js/plugins/jquery.nanoscroller.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lite/js/plugins/list.min.js"></script>	
    <script src="<?php echo base_url(); ?>assets/lite/js/main.js"></script>
	<script src="<?php echo base_url(); ?>assets/lite/js/datepicker/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/lite/js/datepicker/jquery.validate.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/lite/js/datepicker/select2.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/lite/js/datepicker/bootstrap-datepicker.js"></script>
	<script src="<?php echo base_url(); ?>assets/lite/js/datepicker/main.js"></script>
	<script src="<?php echo base_url(); ?>assets/lite/js/datepicker/form-validation.js"></script>
	<script>
		jQuery(document).ready(function() {       
		FormValidation.init();
	});
	</script>
  </body>
</html>
       
