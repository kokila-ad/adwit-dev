    
<footer class="footer">
		<div class="footer-copyright ">
			<div class="container">
			 <div class="row">
				<div class="col-md-6 col-sm-6 col-xs-12 ">
					<p class="margin-0"><a href="#" title="">&copy; Adwit Global</a></p>
				</div>

				 <div class="col-md-6 col-sm-6 col-xs-12">
					 <p class="footer-version margin-0">Version 3.2</p>
				</div>
			</div>
		   </div>
		</div>  
</footer>

</div><!-- /#wrapper -->
	   

    <script src="<?php echo base_url();?>assets/page_design/js/vendor/jquery-ui.min.js"></script>
    <script src="<?php echo base_url();?>assets/page_design/js/plugins/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/page_design/js/plugins/awemenu.min.js"></script>
    <script src="<?php echo base_url();?>assets/page_design/js/plugins/headroom.min.js"></script>
    <script src="<?php echo base_url();?>assets/page_design/js/plugins/jquery.parallax-1.1.3.min.js"></script>
    <script src="<?php echo base_url();?>assets/page_design/js/plugins/jquery.nanoscroller.min.js"></script>
    <script src="<?php echo base_url();?>assets/page_design/js/awe-hosoren.js"></script>
    <script src="<?php echo base_url();?>assets/page_design/js/main.js"></script>
    <script src="<?php echo base_url();?>assets/page_design/js/plugins/list.min.js"></script>
    <!-- endbuild -->
	<!-- build:js datepicker -->	
	<script type="text/javascript" src="<?php echo base_url();?>assets/page_design/js/datepicker/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/page_design/js/datepicker/jquery.validate.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/page_design/js/datepicker/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/page_design/js/datepicker/bootstrap-datepicker.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/page_design/js/datepicker/metronic.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/page_design/js/datepicker/form-validation.js"></script>
	<script>
		jQuery(document).ready(function() {       
		FormValidation.init();
		//ComponentsPickers.init();
	});
	</script>
	<!-- end:js datepicker -->
    </body>
</html>
<style>
	.progress{
		margin-bottom:70px;
	}
	.progress-bar-grey{
		background-color: grey;
		border-top-left-radius: 9px ;
		border-bottom-left-radius: 9px ;
	}
	
	.dropzone .dz-message { 
	 margin-top: 4%; 
	 margin-bottom: 4%; 
 } 

.font-12{
	font-size:12px;
}
textarea,
textarea::-webkit-textarea-placeholder {
    font-size: 12px !important;
   
}



.progress-bar-border{
	border:1px solid #aaa;
	height:20px;
	border-radius:15px;
	background-color: #aaa;
}
.progress-bar {
	text-align: center !important;
}
	
</style>
