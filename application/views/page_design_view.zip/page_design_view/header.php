<!DOCTYPE html>
<html class="no-js" lang="">
    <head>
        
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Page Design|AdwitAds</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

        <link rel="stylesheet" href="<?php echo base_url();?>assets/page_design/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/page_design/css/datepicker.css"/>
		<link rel="stylesheet" href="<?php echo base_url();?>assets/page_design/css/awemenu.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/page_design/css/font-awesome.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/page_design/css/main.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/page_design/css/main2.css">
        <script src="<?php echo base_url();?>assets/page_design/js/vendor/jquery-1.11.3.min.js"></script>
         <script src="<?php echo base_url();?>assets/page_design/js/vendor/modernizr-2.8.3.min.js"></script>
        <script src="<?php echo base_url();?>assets/page_design/js/vendor/jquery-1.11.3.min.js"></script>	
        <!-- dropzone-->
		<link href="<?php echo base_url();?>assets/page_design/css/dropzone/dropzone.css" type="text/css" rel="stylesheet" />
		<script src="<?php echo base_url();?>assets/page_design/css/dropzone/dropzone.min.js"></script>
		<!-- end-dropzone-->		
		<!-- pagination -->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/page_design/css/datatables.min.css"/>

		<script type="text/javascript" src="<?php echo base_url();?>assets/page_design/js/datatables.min.js"></script>
        <script>window.SHOW_LOADING = false;</script>
		<script>
			 $(document).ready(function(){
				 $("#optional").hide();
					$("#clickshow").hide();
                    $(".clickedit").hide();	
                     $("#uplods").hide();    
				 $("#showoptional").click(function(){
					$("#optional").toggle();      
				 });

                  $("#sub").click(function(){
                    $("#uplods").show(); 
                    $("#sub").hide();     
                 });

                  $("#addclick").click(function(){
                    $("#clickshow").show();  
                    $("#addclick").hide();      
                 });
                $(".editclick").click(function(){
					var id = $(this).attr("data-id");
					//alert('ID : '+id);   
                    $("#clickedit"+id).show();  
                    $("#editclick"+id).hide();     
                 });

                $("#showadvancesearch").click(function(){
                    $("#advancesearch").toggle();  
                    $("#search").toggle();          
                  });
                 
                 $("#showsearch").click(function(){
                    $("#advancesearch").toggle();  
                    $("#search").toggle();          
                  });  
			  });
			  
			jQuery(function($) {
				$('#dateControlledByRange').on('input', function() {
					$('#rangeControlledByDate').prop('valueAsNumber', $.prop(this, 'valueAsNumber'));
				});
				$('#rangeControlledByDate').on('input', function() {
					$('#dateControlledByRange').prop('valueAsNumber', $.prop(this, 'valueAsNumber'));
				});
			});			
		</script>
		<script type="text/javascript">
			$(document).ready(function(){
				$("select").change(function(){
					$(this).find("option:selected").each(function(){
						if($(this).attr("value")=="custom"){
							$(".box").not(".custom").hide();
							$(".custom").show();
						}
					   else{
							$(".box").hide();
						}
					});
				}).change();
			});
		</script>
   <link rel="shortcut icon" href="<?php echo base_url();?>assets/page_design/favicon.ico"/>
	</head>

<body>
 <!-- // LOADING -->
        <div class="awe-page-loading">
            <div class="awe-loading-wrapper">
                <div class="awe-loading-icon">
                    <span class="icon icon-logo"></span>
                </div>
                
                <div class="progress">
                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
        <!-- // END LOADING -->      
<div id="wrapper" class="main-wrapper ">        
    <header id="header" class="awe-menubar-header">
        <nav class="awemenu-nav navbar-fixed-top" data-responsive-width="1200">
            <div class="container">
                <div class="awemenu-container">
                    <?php 
                    $uid = $this->session->userdata('uId');
                    $user = $this->db->query("SELECT `first_name`, `image` FROM `users` WHERE `id` = '$uid'")->row_array();
                    ?>
              
                    <div class="awe-logo">
                        <a href="<?php echo base_url().index_page()."Pagedesign_home"?>" title=""><img src="<?php echo base_url();?>assets/page_design/img/logo.svg" style="width:60%;" alt=""></a>
                    </div><!-- /.awe-logo -->
                    <ul class="awemenu awemenu-right">
						<li class="awemenu-item">
                            <a href="<?php echo base_url().index_page()."/Pagedesign_home/dashboard";?>" title="">Dashboard</a>   
                        </li>
                        <li class="awemenu-item">
                            <a href="<?php echo base_url().index_page()."/Pagedesign_home/page_proceed";?>">Place Order</a>
                        </li>
						<li class="awemenu-item">
                            <a href="<?php echo base_url().index_page()."/Pagedesign_home/help";?>" title="">Help</a>
                        </li>
						<li class="awemenu-item">
                            <a href="<?php echo base_url().index_page()."/Pagedesign_home/billing";?>" title="">Billing</a>   
                        </li>
						<li class="awemenu-item">
                            <a class=" border-right" href="#">
                                <img src="<?php echo base_url().$user['image']; ?>" alt="profile">
                                <?php echo $user['first_name']; ?>
                            </a>
                            <ul class="awemenu-submenu awemenu-megamenu" data-width="170px" data-animation="fadeup">
                                <li class="awemenu-megamenu-item padding-0">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <ul class="list-unstyled">
                                                    <li class="awemenu-item border-bottom">
                                                        <a class="padding-0" href="<?php echo base_url().index_page()."/Pagedesign_home/profile";?>">View Profile</a>   
                                                    </li>
												    <!-- <li class="awemenu-item border-bottom">
                                                        <a class="padding-0" href="<?php echo base_url();?>assets/page_design/faq.php">Help</a>
                                                    </li> -->
													<li class="awemenu-item padding-0">
                                                        <a href="<?php echo base_url().index_page()."/Login/shutdown"?>" title="">Sign out</a>
                                                    </li>                                         
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul><!-- /.awemenu -->
                </div>
            </div><!-- /.container -->
        </nav><!-- /.awe-menubar -->
    </header>