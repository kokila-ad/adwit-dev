<!-- pagination -->
			<script type="text/javascript" src="<?php echo base_url(); ?>assets/india_client/css/pagination/datatables.min.js"></script>

			<script type="text/javascript" charset="utf-8">
				$(document).ready(function() {
					$('#example').DataTable();
				} );
			</script>
<!-- endpagination -->

        <footer class="footer">
                <div class="footer-copyright ">
                    <div class="container">
					 <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <p class="margin-0"><a href="#" title="">&copy; adWitads</a></p>
                        </div>

                         <div class="col-md-6 col-sm-6 col-xs-12">
                             <p class="footer-version margin-0">Version 4.1</p>
                        </div>
                    </div>
				   </div>
                </div><!-- /.footer-copyright -->          
        </footer><!-- /footer -->

        </div><!-- /#wrapper -->

             
    
    <script src="<?php echo base_url(); ?>assets/india_client/js/vendor/jquery-ui.min.js"></script>
    <script>$.widget.bridge('uitooltip', $.ui.tooltip);</script>

    <!-- build:js js/plugins.js -->
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/bootstrap.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/awemenu.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/headroom.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/hideshowpassword.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/jquery.parallax-1.1.3.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/jquery.nanoscroller.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/swiper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/jquery.countdown.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/easyzoom.js"></script>

    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/masonry.pkgd.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/isotope.pkgd.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/imagesloaded.pkgd.min.js"></script>

    <!-- endbuild -->

    <!-- build:js js/main.js -->
    <script src="<?php echo base_url(); ?>assets/india_client/js/awe/awe-carousel-branch.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/awe/awe-carousel-blog.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/awe/awe-carousel-products.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/awe/awe-carousel-testimonial.js"></script>

    <script src="<?php echo base_url(); ?>assets/india_client/js/awe-hosoren.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/main.js"></script>
    <!-- endbuild -->

    <!-- build:js js/docs.js -->
    <script src="<?php echo base_url(); ?>assets/india_client/js/plugins/list.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/india_client/js/docs.js"></script>
    <!-- endbuild -->
	
	<!-- build:js datepicker -->	
	<script src="<?php echo base_url(); ?>assets/india_client/css/datepicker/js/jquery.validate.min.js" type="text/javascript" ></script>
	<script src="<?php echo base_url(); ?>assets/india_client/css/datepicker/js/select2.min.js" type="text/javascript" ></script>
	<script src="<?php echo base_url(); ?>assets/india_client/css/datepicker/js/bootstrap-datepicker.js" type="text/javascript" ></script>
	<script src="<?php echo base_url(); ?>assets/india_client/css/datepicker/js/metronic.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/india_client/css/datepicker/js/layout.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/india_client/css/datepicker/js/demo.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/india_client/css/datepicker/js/form-validation.js" type="text/javascript" ></script>
	<script>
		jQuery(document).ready(function() {       
			FormValidation.init();
			ComponentsPickers.init();
	});
	</script>
	<!-- end:js datepicker -->
	
    </body>
</html>


